StableMatchingArrays.java contains the algorithm
Usage: java StableMatchingArrays < [input file]

SMTestTool.java contains the test tool that we have used for testing the output.
Usage: java SMTestTool [output from algorithm] [expected output file]
